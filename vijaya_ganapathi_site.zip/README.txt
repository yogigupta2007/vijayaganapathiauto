
Vijaya Ganapathi Auto - Website Package
--------------------------------------

Files included:
- index.html
- style.css
- images/tyre.jpg  (placeholder image)
- README.txt (this file)

Quick steps to deploy on Netlify:
1. Go to https://app.netlify.com and sign up / log in.
2. Drag-and-drop the folder 'vijaya_ganapathi_site' (the entire folder) into Netlify "Sites" -> "Add new site" -> "Deploy manually".
3. Netlify will deploy and give a temporary site (e.g., https://something.netlify.app).
4. To connect your custom domain (vijayaganapathiauto.com), go to Site settings -> Domain management -> Add custom domain and follow instructions. Update your registrar DNS records as Netlify instructs.
5. SSL (Let's Encrypt) is free from Netlify once DNS is set up.

Contact form (Formspree) setup:
1. Sign up at https://formspree.io and create a new form. They will give you a form endpoint like https://formspree.io/f/yourFormID
2. Open index.html and replace the form 'action' value (https://formspree.io/f/FORM_ID) with your actual form endpoint.
3. Optionally, configure Formspree to forward form submissions to your email.

Notes:
- Replace images/images in the images/ folder with your real photos (keep filenames or update index.html accordingly).
- To add the scratch card page later, create a folder 'scratch' and put scratch index.html there: /scratch/index.html and link from the main site.
- If you need me to add Google Maps embed or Whatsapp direct chat link customization, tell me the phone number and address and I'll inject it into the page.
